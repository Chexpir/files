package io.quarkus.reproducer;

import io.smallrye.mutiny.Uni;
import javax.enterprise.context.ApplicationScoped;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.eclipse.microprofile.rest.client.inject.RegisterRestClient;

@Path("/something")
@RegisterRestClient(configKey = "some-client")
@Consumes(MediaType.APPLICATION_JSON)
@ApplicationScoped
public interface SomeRestClient {

    @POST
    @Path("/{something}")
    @Produces(MediaType.APPLICATION_JSON)
    Uni<Response> sendResult(@PathParam("something") String something);

}
