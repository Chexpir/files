package io.quarkus.reproducer;

import com.fasterxml.jackson.core.JsonProcessingException;

import io.quarkus.vertx.ConsumeEvent;
import io.smallrye.mutiny.Uni;
import java.io.Closeable;
import java.io.IOException;
import java.net.URI;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import javax.enterprise.context.ApplicationScoped;
import org.eclipse.microprofile.rest.client.inject.RestClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@ApplicationScoped
public class Adapter {

    private static final Logger log = LoggerFactory.getLogger(Adapter.class);

    private final Integer retryAttempts = 2;
    private final Long retryBackOffMillis = 2000L;
    private final SomeRestClient restClient;

    public Adapter(@RestClient SomeRestClient restClient) {
        this.restClient = restClient;
    }

    @ConsumeEvent("webhook")
    public void sendWebhookNotification(String message) {
        Uni.createFrom()
                .item(message)
                .call(m -> sendWebhook(m))
                .onFailure()
                .retry()
                .withBackOff(Duration.ofMillis(retryBackOffMillis))
                .atMost(retryAttempts)
                .subscribe()
                .with(success -> Uni.createFrom().voidItem(),
                        error -> log.warn("[{}] Failed to send notification"));
    }

    private Uni<Void> sendWebhook(String message) {
        log.info("Here preparing webhook");
        return restClient.sendResult(message)
                .replaceWithVoid()
                .invoke(() -> log.info("[{}] Successfully sent"));

    }
}
