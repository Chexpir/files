package io.quarkus.reproducer;

import io.vertx.core.eventbus.EventBus;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/hello")

public class GreetingResource {

    private final EventBus eventBus;

    public GreetingResource(EventBus eventBus) {
        this.eventBus = eventBus;
    }

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String hello() {
        eventBus.send("webhook", "something");
        return "Hello RESTEasy";
    }
}